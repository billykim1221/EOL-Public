import click

from skiacmd import *

#
# Define user command
#

def iterate_eol():
    # get current lot number
    lot_num = get_lot_number()
    # logging current date and lot number
    log_header(lot_num)
    set_except_enable(True)
    try:
        # restart jlink
        restart_jlink()
        # start EOL and wait
        #check_eol(True)
        # check partition
        #info()
        # check UID
        #uid()
        # clear partition
        recover()
        # restart EOL and wait
        restart_eol()
        # execute mcu partition command
        part()
        # restart EOL and wait
        restart_eol()
        # check partition
        info()
        # create mpi-boot and flashing bootloader
        create_boot_mpi(lot_num)
        flash_boot()
        # restart EOL and wait
        restart_eol()
        # install all keys
        install()
        # verify all keys
        verify()
        # secure boot
        #secure()
        # check secure boot
        check()
        # finalize
    except SkiaCmdError as e:
        log(str(e) + "\n", TermColor.KRED)
        set_except_enable(False)
        return
    update_lot_number()
    set_except_enable(False)

def iterate_test():
    # get current lot number
    #lot_num = get_lot_number()
    # logging current date and lot number
    #log_header(lot_num)
    set_except_enable(True)
    try:
        # restart jlink
        restart_jlink()
        # start EOL and wait
        check_eol(True)
        # check UID
        #uid()
        # test procedure
        test()
        # finalize
    except SkiaCmdError as e:
        log(str(e) + "\n", TermColor.KRED)
        set_except_enable(False)
        return
    #update_lot_number()
    set_except_enable(False)

def iterate_recover():
    # get current lot number
    #lot_num = get_lot_number()
    # logging current date and lot number
    #log_header(lot_num)
    set_except_enable(True)
    try:
        # restart jlink
        restart_jlink()
        # start EOL and wait
        #check_eol(True)
        # check UID
        #uid()
        # test procedure
        recover()
        # erase chip
        erase_chip()
        # restart jlink (re-load)
        #restart_jlink()
        # finalize
    except SkiaCmdError as e:
        log(str(e) + "\n", TermColor.KRED)
        set_except_enable(False)
        return
    #update_lot_number()
    set_except_enable(False)

def iterate_lock():
    set_except_enable(True)
    try:
        # restart jlink
        restart_jlink()
        secure()
        lock_jtag()
        #reset() 
        #check_lock_status()
        # finalize
    except SkiaCmdError as e:
        log(str(e) + "\n", TermColor.KRED)
        set_except_enable(False)
        return
    set_except_enable(False)


def prompt_erase_chip():
    click.confirm("Are you sure ?", abort=True)
    set_except_enable(True)
    try:
        erase_chip()
    except SkiaCmdError as e:
        log(str(e) + "\n", TermColor.KRED)
    set_except_enable(False)

#
# register user cli command
#

register_cli_command(
    "iterate_eol", 
    iterate_eol, 
    "execute key installation process",
    0
)

register_cli_command(
    "iterate_recover", 
    iterate_recover, 
    "execute erase key and erase chip",
    1 
)

register_cli_command(
    "iterate_test", 
    iterate_test, 
    "execute test process",
    2 
)

#
# register gui command
#

register_gui_command(
    "test", 
    iterate_test, 
    "execute test process",
    0 
)

register_gui_command(
    "install", 
    iterate_eol, 
    "execute key installation process",
    0
)

register_gui_command(
    "lock", 
    iterate_lock, 
    "execute lock jtag",
    1
)

